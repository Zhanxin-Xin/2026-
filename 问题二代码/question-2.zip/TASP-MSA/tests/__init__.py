"""Tests for TASP-MSA."""
